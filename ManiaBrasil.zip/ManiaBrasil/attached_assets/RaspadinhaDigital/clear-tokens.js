localStorage.removeItem('affiliateToken'); localStorage.removeItem('affiliateRememberMe');
